def nyquist(samplerate):
	'''computes max signal frequency detected based on samplerate.
	'''
	print(samplerate/2)